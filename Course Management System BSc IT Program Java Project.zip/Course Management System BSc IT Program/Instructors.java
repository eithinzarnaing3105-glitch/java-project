package project;
import java.util.ArrayList;

public class Instructors {
    private String instructorName;
    
    private ArrayList<String> courses; 
    public Instructors(String instructorName) {
        this.instructorName = instructorName;
       this.courses = new ArrayList<>();
    }

    // Add a course to the instructor's list
    public void addCourse(String courseName) {
        courses.add(courseName);
    }

    // Get all courses
    public ArrayList<String> getCourses() {
        return courses;
    }

    // Display all instructor info and their courses
    public void displayInstructorInfo() {
        System.out.println("Instructor Name: " + instructorName);
        System.out.println("Courses managed:");
        for (String course : courses) {
            System.out.println("- " + course);
        }
    }

    // Getter for instructor name
    public String getInstructorName() {
        return instructorName;
    }
//Setter for instructor name
    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }
}