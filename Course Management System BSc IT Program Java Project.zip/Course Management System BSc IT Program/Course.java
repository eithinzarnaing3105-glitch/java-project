package project;
//The course class contains information about a course such as course ID, name, instructor, time, and room.

public class Course {
String courseID;
String coursename;
String instructor;
String time;
int room;

//Constructor to initialize course details
public Course (String courseID,String coursename,String instructor,String time,int room) {
	this.courseID = courseID;
	this.coursename = coursename;
	this.instructor = instructor;
	this.time = time;
	this.room = room;
}

//Display course information
public void displaycourse() {
	System.out.println("\n---------------------------------------");
	System.out.println("Course ID: "+ courseID);
	System.out.println("Course name: "+ coursename);
	System.out.println("Course instructor: "+ instructor);
	System.out.println("Time: "+ time);
	System.out.println("Room: "+ room );
}
}