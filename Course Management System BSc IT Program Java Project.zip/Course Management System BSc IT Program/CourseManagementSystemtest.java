package project;
import java.util.Scanner;
public class CourseManagementSystemtest {
// Main class to run the Course Management System
	public static void main(String[] args) {
		// Create Students objects
	    Student s1 = new Student("Sham Bahadu","2307100005");
	    Student s2 = new Student("Rachaphon Bhetcharut","2306020001");
	    Student s3 = new Student("Vadim Bushtrust","2311130002");
	    Student s4 = new Student ("Lawrence Joseph Calleya","2308230002");
	    Student s5 = new Student("Kanravi Charoentanaset","2402290003");
	    Student s6 = new Student("Aleksei Dudkin","2303240002");
	    Student s7 = new Student("Vladislav Ivanitskii","2311080008");
	    Student s8 = new Student("Cholticha Khanijomdi","2306280009");
	    Student s9 = new Student("Thanawat Khanijomdi","2306280005");
	    Student s10 = new Student("Taeli Kim","1907060017");
	    Student s11= new Student("Tunchanoke kongpon","2311130009");
	    Student s12 = new Student("Oggha Gwan Myint","2310060003");
	    Student s13 = new Student ("Ei Thinzar Naing","2310060002");
	    Student s14 = new Student ("Apinut Naknopmanee","2302210004");
	    Student s15 = new Student ("Thomas Thawan Nuetzel","2111010009");
	    Student s16 = new Student ("Ratchanon Ogawa","180530003");
	    Student s17 = new Student ("Chakri Sodsroi","2203070017");
	    Student s18 = new Student ("Settha Srihadech", "2206300024");
	    Student s19 = new Student ("Nopparit Tamanun","1906050014");
	    Student s20 = new Student ("Raneen Yusoh", "2311160018");
	    
		//Create Courses Instructor objects
	    Instructors IN01 = new Instructors ("Dr. Surekha Lanka");
	    IN01.addCourse("ITE101");
	    IN01.addCourse("ITE221");
	    IN01.addCourse("ITE240");
	    Instructors IN02 = new Instructors ("Dr. Firouz Anaraki");
	    IN02.addCourse("ITE102");
	    IN02.addCourse("ITE224");
	    IN02.addCourse("ITE223");
	    Instructors IN03 = new Instructors ("Dr. Nay Myo Sandar");
	    IN03.addCourse("ITE103");
	    IN03.addCourse("ITE120");
	    IN03.addCourse("ITE441");
	    IN03.addCourse("ITE420");
	    Instructors IN04 = new Instructors ("Dr. Mohammadamin Daras");
	    IN04.addCourse("ITE104");
	    IN04.addCourse("ITE231");
	    IN04.addCourse("ITE475");
	    Instructors IN05 = new Instructors ("Aj. Thinzar Aung Win");
	    IN05.addCourse("ITE210");
	    IN05.addCourse("ITE479");
	    IN05.addCourse("ITE254");
	    Instructors IN06 = new Instructors ("Aj. Shuvra Tripura");
	    IN06.addCourse("ITE321");
	    IN06.addCourse("ITE331");
	    IN06.addCourse("ITE442");
	    
	    //Create Courses objects
	    Course ITE101 = new Course("ITE101", "Information Technology Fundamentals", "Dr. Surekha Lanka", "Mon & Thu 8:30 to 10:30", 2301);
	    Course ITE102 = new Course("ITE102", "Discrete Mathematics Structure", "Dr. Firouz Anaraki", "Tue & Fri 8:30 to 10:30", 1303);
	    Course ITE103 = new Course("ITE103", "Introduction to Data Structure and Algorithms Analysis", "Dr. Nay Myo Sandar", "Mon & Thu 10:30 to 12:30", 2505);
	    Course ITE104 = new Course("ITE104", "Computer Organization", "Dr. Mohammadamin Daras", "Tue & Fri 10:30 to 12:30", 2206);
	    Course ITE210 = new Course("ITE210", "Social and Professional Issues in Information Technology", "Aj, Thinzar Aung Win", "Tue & Fri 12:30 to 14:30", 2401);
	    Course ITE321 = new Course("ITE321", "System Analysis, Design, and Implementation", "Aj. Shuvra Tripura", "Tue & Fri 12:30 to 14:30", 1303);
	    Course ITE120 = new Course("ITE120", "Web development I", "Dr. Nay Myo Sandar", "Mon & Thu 12:30 to 14:30", 2305);
	    Course ITE224 = new Course("ITE224", "Introduction to Data Science", "Dr. Firouz Anaraki", "Mon & Tue 8:30 to 10:30", 2505);
	    Course ITE233 = new Course("ITE233", "Introduction to internet of Things", "Dr. Firouz Anaraki", "Mon & Thu 10:30 to 12:30", 2305);
	    Course ITE221 = new Course("ITE221", "Programming I", "Dr. Surekha Lanka", "Mon & Thu 14:30 to 16:30", 2301);
	    Course ITE231 = new Course("ITE231", "System Administration and Maintenance", "Dr. Mohammadamin Daras", "Tue & Fri 8:30 to 10:30", 2206);
	    Course ITE240 = new Course("ITE240", "Operating System", "Dr. Surekha Lanka", "Tue & Fri 10:30 to 12:30", 2401);
	    Course ITE479 = new Course("ITE479", "IT Planning and Project Management", "Aj. Thinzar Aung Win", "Tue & Fri 14:30 to 16:30", 1303);
	    Course ITE331 = new Course("ITE331", "Introduction to 3D Modeling and Virtual Reality", "Aj. Shuvra Tripura", "Mon & Thu 14:30 to 16:30", 2505);
	    Course ITE441 = new Course("ITE441", "Database Management System I", "Dr. Nay Myo Sandar", "Mon & Thu 8:30 to 10:30", 2305);
	    Course ITE442 = new Course("ITE442", "Database Management Systems II", "Aj. Shuvra Tripura", "Tue & Fri 10:30 to 12:30", 2401);
	    Course ITE222 = new Course("ITE222", "Programming II", "Dr. Surekha Lanka", "Tue & Fri 14:30 to 16:30", 2403);
	    Course ITE254 = new Course("ITE254", "Human Computer Interaction", "Aj. Thinzar Aung Win", "Mon & Thu 12:30 to 14:30", 2301);
	    Course ITE420 = new Course("ITE420", "Information Assurance and Security I", "Dr. Nay Myo Sandar", "Tue & Fri 14:30 to 16:30", 2206);
	    Course ITE475 = new Course("ITE475", "Network I", "Dr. Mohammadamin Daras", "Mon & Thu 14:30 to 16:30", 2203);

	    
	    
	    // user console
	    Scanner sc = new Scanner(System.in);
	    System.out.println("Course Schedule for Term 3/2024 ");
	    System.out.println("If you're instructor, Enter your first name. If you're student, Enter your student ID.");
	    String id = sc.next();
	    
	    // Switch case to display student and course info
	    switch(id) {
	    case "Surekha":
	    	IN01.displayInstructorInfo();
	    	ITE101.displaycourse();
	    	ITE221.displaycourse();
	    	ITE240.displaycourse();
	    	break;
	    case "Firouz":
	    	IN02.displayInstructorInfo();
	    	ITE102.displaycourse();
	    	ITE224.displaycourse();
	    	ITE233.displaycourse();
	    	break;
	    case "Nay":
	    	IN03.displayInstructorInfo();
	    	ITE103.displaycourse();
	    	ITE120.displaycourse();
	    	ITE441.displaycourse();
	    	ITE420.displaycourse();
	    	break;
	    case "Mohammadamin":
	    	IN04.displayInstructorInfo();
	    	ITE104.displaycourse();
	    	ITE231.displaycourse();
	    	ITE475.displaycourse();
	    	break;
	    case "Thinzar":
	    	IN05.displayInstructorInfo();
	    	ITE210.displaycourse();
	    	ITE479.displaycourse();
	    	ITE254.displaycourse();
	    	break;
	    case "Shuvra":
	    	IN06.displayInstructorInfo();
	    	ITE321.displaycourse();
	    	ITE331.displaycourse();
	    	ITE442.displaycourse();
	    	break;
	    case "2307100005":
	    	s1.displayinfo();
	    	ITE101.displaycourse(); 
	    	ITE102.displaycourse();
	    	ITE120.displaycourse();
	    	ITE210.displaycourse();
	    	break;
	    case "2306020001":
	    	s2.displayinfo();
	    	ITE101.displaycourse(); 
	    	ITE102.displaycourse();
	    	ITE120.displaycourse();
	    	ITE210.displaycourse();
	    	break;
	    case "2311130002":
	    	s3.displayinfo();
	    	ITE101.displaycourse(); 
	    	ITE102.displaycourse();
	    	ITE120.displaycourse();
	    	ITE210.displaycourse();
	    	break;
	    case "2308230002":
	    	s4.displayinfo();
	    	ITE101.displaycourse(); 
	    	ITE102.displaycourse();
	    	ITE120.displaycourse();
	    	ITE210.displaycourse();
	    	break;
	    case "2402290003":
	    	s5.displayinfo();
	    	ITE103.displaycourse(); 
	    	ITE221.displaycourse();
	    	ITE321.displaycourse();
	    	ITE240.displaycourse();
	    	break;
	    case "2303240002":
	    	s6.displayinfo();
	    	ITE103.displaycourse(); 
	    	ITE221.displaycourse();
	    	ITE321.displaycourse();
	    	ITE240.displaycourse();
	    	break;
	    case "2311080008":
	    	s7.displayinfo();
	    	ITE103.displaycourse(); 
	    	ITE221.displaycourse();
	    	ITE321.displaycourse();
	    	ITE240.displaycourse();
	    	break;
	    case "2306280009":
	    	s8.displayinfo();
	    	ITE103.displaycourse(); 
	    	ITE221.displaycourse();
	    	ITE321.displaycourse();
	    	ITE240.displaycourse();
	    	break;
	    case "2306280005":
	    	s9.displayinfo();
	    	ITE224.displaycourse(); 
	    	ITE233.displaycourse();
	    	ITE222.displaycourse();
	    	ITE442.displaycourse();
	    	break;
	    case "1907060017":
	    	s10.displayinfo();
	    	ITE224.displaycourse(); 
	    	ITE233.displaycourse();
	    	ITE222.displaycourse();
	    	ITE442.displaycourse();
	    	break;
	    case "2311130009":
	    	s11.displayinfo();
	    	ITE224.displaycourse(); 
	    	ITE233.displaycourse();
	    	ITE222.displaycourse();
	    	ITE442.displaycourse();
	    	break;
	    case "2310060003":
	    	s12.displayinfo();
	    	ITE224.displaycourse(); 
	    	ITE233.displaycourse();
	    	ITE222.displaycourse();
	    	ITE442.displaycourse();
	    	break;
	    case "2310060002":
	    	s13.displayinfo();
	    	ITE254.displaycourse(); 
	    	ITE475.displaycourse();
	    	ITE104.displaycourse();
	    	ITE479.displaycourse();
	    	break;
	    case "2302210004":
	    	s14.displayinfo();
	    	ITE254.displaycourse(); 
	    	ITE475.displaycourse();
	    	ITE104.displaycourse();
	    	ITE479.displaycourse();
	    	break;
	    case "2111010009":
	    	s15.displayinfo();
	    	ITE254.displaycourse(); 
	    	ITE475.displaycourse();
	    	ITE104.displaycourse();
	    	ITE479.displaycourse();
	    	break;
	    case "1805300003":
	    	s16.displayinfo();
	    	ITE254.displaycourse(); 
	    	ITE475.displaycourse();
	    	ITE104.displaycourse();
	    	ITE479.displaycourse();
	    	break;
	    case "2203070017":
	    	s17.displayinfo();
	    	ITE441.displaycourse(); 
	    	ITE231.displaycourse();
	    	ITE420.displaycourse();
	    	ITE331.displaycourse();
	    	break;
	    case "2206300024":
	    	s18.displayinfo();
	    	ITE441.displaycourse(); 
	    	ITE231.displaycourse();
	    	ITE420.displaycourse();
	    	ITE331.displaycourse();
	    	break;
	    case "1906050014":
	    	s19.displayinfo();
	    	ITE441.displaycourse(); 
	    	ITE231.displaycourse();
	    	ITE420.displaycourse();
	    	ITE331.displaycourse();
	    	break;
	    case "2311160018":
	    	s20.displayinfo();
	    	ITE441.displaycourse(); 
	    	ITE231.displaycourse();
	    	ITE420.displaycourse();
	    	ITE331.displaycourse();
	    	break;
	    	default:
	    		System.out.println("Invalid.");
	    }
	    
	    // Close the scanner after use
	    sc.close();
		}

	}


