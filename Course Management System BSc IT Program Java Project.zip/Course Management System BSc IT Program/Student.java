package project;

// The student class holds information about a student such as name and ID.
public class Student {
private String name;
private String ID;

//Constructor to initialize student name and ID
public Student(String name, String ID) {
	this.name = name;
	this.ID = ID;
	
}
 //Getter for name
public String getName() {
	return name;
}
//Setter for name
public void setName(String name) {
	this.name = name;
}
//Getter for ID
public String getID() {
	return ID;
}
//Setter for ID
public void setID(String iD) {
	ID = iD;
}

// Display student information
public void displayinfo() {
	System.out.println("\nName: "+name);
	System.out.println("Student ID: "+ ID);
	
}
}
